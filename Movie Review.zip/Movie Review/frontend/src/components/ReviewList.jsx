import React from 'react';
import ReviewCard from './ReviewCard';

function ReviewList({ reviews, onDeleteReview }) {
  if (reviews.length === 0) {
    return <p style={{ textAlign: 'center' }}>No task assigned yet. Be the first!</p>;
  }

  return (
    <div>
      {reviews.map((review) => (
        <ReviewCard key={review.id} {...review} onDelete={() => onDeleteReview(review.id)} />
      ))}
    </div>
  );
}

export default ReviewList;
