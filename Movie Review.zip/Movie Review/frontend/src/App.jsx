import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import './App.css';

function App() {
  const [title, setTitle] = useState('');
  const [review, setReview] = useState('');
  const [rating, setRating] = useState('');
  const [reviews, setReviews] = useState([]);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!title || !review || !rating) return;

    const newReview = { title, review, rating };
    setReviews([newReview, ...reviews]);
    setTitle('');
    setReview('');
    setRating('');
  };

  return (
    <div className="container">
      {/* Navigation */}
      <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '10px', marginBottom: '20px' }}>
        <Link to="/login"><button className="nav-button">Login</button></Link>
        <Link to="/signup"><button className="nav-button">Sign Up</button></Link>
      </div>

      {/* Heading */}
      <h2 style={{ textAlign: 'center', marginBottom: '20px' }}>
        🎬 <span style={{ color: '#ff5733' }}>Movie Reviews</span>
      </h2>

      {/* Review Form */}
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          placeholder="Movie Title"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
        />
        <textarea
          placeholder="Your review"
          value={review}
          onChange={(e) => setReview(e.target.value)}
        />
        <input
          type="number"
          placeholder="Rating (1-5)"
          min="1"
          max="5"
          value={rating}
          onChange={(e) => setRating(e.target.value)}
        />
        <button type="submit">Submit Review</button>
      </form>

      {/* Review List */}
      {reviews.map((r, index) => (
        <div key={index} className="review-box">
          <h3 style={{ color: '#facc15' }}>{r.title} ⭐ {r.rating}</h3>
          <p>{r.review}</p>
        </div>
      ))}
    </div>
  );
}

export default App;
