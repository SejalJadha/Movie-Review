import React, { useState } from 'react';

function AddHotelForm({ onAddHotel }) {
  const [name, setName] = useState('');
  const [location, setLocation] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    onAddHotel({ name, location });
    setName('');
    setLocation('');
  };

  return (
    <form onSubmit={handleSubmit}>
      <h2>Add Hotel</h2>
      <input
        type="text"
        placeholder="Hotel Name"
        value={name}
        onChange={(e) => setName(e.target.value)}
        required
      />
      <input
        type="text"
        placeholder="Location"
        value={location}
        onChange={(e) => setLocation(e.target.value)}
        required
      />
      <button type="submit">Add Hotel</button>
    </form>
  );
}

export default AddHotelForm;
