import React from 'react';
import './HotelList.css';

const HotelList = ({ hotels, onBookRoom, onDeleteHotel }) => {
  return (
    <div className="hotel-list">
      <h2>Hotel List</h2>
      {hotels.length === 0 ? (
        <p>No hotels available.</p>
      ) : (
        <ul>
          {hotels.map((hotel, index) => (
            <li key={index} className="hotel-item">
              <h3>{hotel.name}</h3>
              <p>{hotel.location}</p>
              <p>{hotel.price} per night</p>
              <button onClick={() => onBookRoom(hotel)}>Book Room</button>
              <button
                onClick={() => onDeleteHotel(index)}
                className="delete-btn"
              >
                Delete
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default HotelList;
