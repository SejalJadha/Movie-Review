import React from 'react';
import './Navbar.css';

function Navbar({ onNavigate }) {
  return (
    <nav>
      <button onClick={() => onNavigate('login')}>Login</button>
      <button onClick={() => onNavigate('signup')}>Signup</button>
      <button onClick={() => onNavigate('add')}>Add Hotel</button>
    </nav>
  );
}

export default Navbar;
