import React, { useState } from 'react';

function BookRoomForm({ hotel, onBack }) {
  const [name, setName] = useState('');
  const [days, setDays] = useState(1);

  const handleSubmit = (e) => {
    e.preventDefault();
    alert(`Room booked at ${hotel.name} for ${name} for ${days} day(s)!`);
    onBack();
  };

  return (
    <form onSubmit={handleSubmit}>
      <h2>Book Room at {hotel.name}</h2>
      <input
        type="text"
        placeholder="Your Name"
        value={name}
        onChange={(e) => setName(e.target.value)}
        required
      />
      <input
        type="number"
        min="1"
        value={days}
        onChange={(e) => setDays(e.target.value)}
        required
      />
      <button type="submit">Book</button>
      <button type="button" onClick={onBack}>Back</button>
    </form>
  );
}

export default BookRoomForm;
