import React, { useState } from 'react';
import Navbar from './components/Navbar';
import HotelList from './components/HotelList';
import AddHotelForm from './components/AddHotelForm';
import BookRoomForm from './components/BookRoomForm';
import Login from './pages/Login';
import Signup from './pages/Signup';
import './App.css';

function App() {
  const [view, setView] = useState('home');
  const [hotels, setHotels] = useState([]);
  const [selectedHotel, setSelectedHotel] = useState(null);

  const handleAddHotel = (hotel) => {
    setHotels([...hotels, hotel]);
    setView('home');
  };

  const handleDeleteHotel = (index) => {
    const updatedHotels = hotels.filter((_, i) => i !== index);
    setHotels(updatedHotels);
  };

  const handleBookRoom = (hotel) => {
    setSelectedHotel(hotel);
    setView('book');
  };

  return (
    <div>
      <Navbar onNavigate={setView} />
      {view === 'login' && <Login />}
      {view === 'signup' && <Signup />}
      {view === 'add' && <AddHotelForm onAddHotel={handleAddHotel} />}
      {view === 'book' && selectedHotel && (
        <BookRoomForm hotel={selectedHotel} onBack={() => setView('home')} />
      )}
      {view === 'home' && (
        <HotelList
          hotels={hotels}
          onBookRoom={handleBookRoom}
          onDeleteHotel={handleDeleteHotel}
        />
      )}
    </div>
  );
}

export default App;
