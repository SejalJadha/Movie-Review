import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import api from '../api';

export default function HomePage() {
  const [polls, setPolls] = useState([]);

  useEffect(() => {
    async function fetchPolls() {
      const res = await api.get('/polls');
      setPolls(res.data);
    }
    fetchPolls();
  }, []);

  return (
    <div>
      <h2>Available Polls</h2>
      {polls.map(poll => (
        <div key={poll._id} style={{ marginBottom: '1rem' }}>
          <Link to={`/poll/${poll._id}`}>
            <h3>{poll.question}</h3>
          </Link>
        </div>
      ))}
    </div>
  );
}
